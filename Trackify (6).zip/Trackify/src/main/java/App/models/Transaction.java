package App.models;

import java.time.LocalDate;

public class Transaction {
    private String id;
    private String userId;
    private LocalDate date;
    private String customer;
    private String item;
    private String paymentMethod;
    private double revenue;
    private double cost;
    private double profit;
    private String notes;

    public Transaction() {}

    // getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public String getCustomer() { return customer; }
    public void setCustomer(String customer) { this.customer = customer; }

    public String getItem() { return item; }
    public void setItem(String item) { this.item = item; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public double getRevenue() { return revenue; }
    public void setRevenue(double revenue) { this.revenue = revenue; }

    public double getCost() { return cost; }
    public void setCost(double cost) { this.cost = cost; }

    public double getProfit() {
        // ensure profit always consistent
        return profit;
    }
    public void setProfit(double profit) { this.profit = profit; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
