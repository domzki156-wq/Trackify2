package App.controllers;

import App.Session;
import App.dao.DaoFactory;
import App.dao.TransactionDao;
import App.dao.UserDao;
import App.models.Transaction;
import App.models.User;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.time.LocalDate;

/**
 * Controller for record-transaction.fxml
 *
 * Responsibilities:
 * - Validate form
 * - Save transaction to DB (TransactionDao)
 * - Update current user's wallet (UserDao)
 * - Call onSaved() callback so dashboard reloads
 *
 * IMPORTANT: DashboardController sets the dialog Stage by calling setOwner(stage)
 * and registers a callback with setOnSaved(...)
 */
public class RecordTransactionController {

    // FXML controls (make sure fx:id in FXML matches)
    @FXML private DatePicker datePicker;
    @FXML private TextField customerField;
    @FXML private TextField itemField;
    @FXML private ComboBox<String> paymentCombo;
    @FXML private TextField revenueField;
    @FXML private TextField costField;
    @FXML private TextArea notesArea;
    @FXML private Button saveBtn;
    @FXML private Button cancelBtn;

    // DAOs
    private final TransactionDao txDao = DaoFactory.getTransactionDao();
    private final UserDao userDao = DaoFactory.getUserDao();

    // Owner stage provided by caller (DashboardController)
    private Stage owner;

    // Callback to notify parent that save completed (or dialog closed)
    private Runnable onSaved;

    @FXML
    private void initialize() {
        // Populate payment methods if not done in FXML
        if (paymentCombo != null && paymentCombo.getItems().isEmpty()) {
            paymentCombo.getItems().addAll("CASH", "GCASH", "PAYPAL", "CARD", "OTHER");
            paymentCombo.getSelectionModel().selectFirst();
        }
        if (datePicker != null) datePicker.setValue(LocalDate.now());
    }

    /**
     * Called by DashboardController before showing dialog so controller has the Stage.
     */
    public void setOwner(Stage owner) {
        this.owner = owner;
    }

    /**
     * Register a callback to be executed after a successful save (useful to refresh UI).
     */
    public void setOnSaved(Runnable callback) {
        this.onSaved = callback;
    }

    @FXML
    private void handleCancel() {
        if (owner != null) owner.close();
        else {
            // safe fallback
            Platform.runLater(() -> {
                if (saveBtn != null && saveBtn.getScene() != null) {
                    saveBtn.getScene().getWindow().hide();
                }
            });
        }
    }

    @FXML
    private void handleSave() {
        try {
            // basic validation
            String cust = safeTrim(customerField);
            String item = safeTrim(itemField);
            String payment = paymentCombo == null ? "CASH" : paymentCombo.getValue();
            double revenue = parseDoubleOrZero(revenueField);
            double cost = parseDoubleOrZero(costField);
            String notes = notesArea == null ? "" : notesArea.getText();

            if (revenue <= 0) {
                showAlert("Validation", "Revenue must be a positive number.", Alert.AlertType.WARNING);
                return;
            }

            if (!Session.isAuthenticated()) {
                showAlert("Not logged in", "Please login before recording a transaction.", Alert.AlertType.WARNING);
                return;
            }

            Transaction tx = new Transaction();
            tx.setDate(datePicker == null ? LocalDate.now() : datePicker.getValue());
            tx.setCustomer(cust);
            tx.setItem(item);
            tx.setPaymentMethod(payment);
            tx.setRevenue(revenue);
            tx.setCost(cost);
            tx.setNotes(notes);
            tx.setUserId(Session.getCurrentUser().getId());

            // persist transaction
            Transaction saved = txDao.save(tx);
            System.out.println("Saved transaction id=" + (saved == null ? "<null>" : saved.getId()) +
                    " for user=" + tx.getUserId());

            // Update user's balance (auto-add revenue)
            // You can choose to add revenue - cost or revenue only; here we add revenue
            User cur = Session.getCurrentUser();
            double newBalance = cur.getBalance() + (saved.getRevenue() - saved.getCost());
            cur.setBalance(newBalance);
            // persist user (UserDao.save or updateBalance)
            try {
                userDao.updateBalance(cur.getId(), newBalance); // if implemented
            } catch (Exception ex) {
                // fallback to save entire user if updateBalance isn't implemented
                userDao.save(cur);
            }

            // Update session user and UI via callback
            Session.setCurrentUser(cur);

            // close dialog using owner Stage (preferred)
            if (owner != null) owner.close();
            else { // fallback: hide via any control scene if available
                if (saveBtn != null && saveBtn.getScene() != null) {
                    saveBtn.getScene().getWindow().hide();
                }
            }

            // notify parent to refresh (run on FX thread)
            if (onSaved != null) {
                Platform.runLater(onSaved);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Failed to save transaction", ex.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // --- helpers ---

    private String safeTrim(TextField f) {
        if (f == null) return "";
        String s = f.getText();
        return s == null ? "" : s.trim();
    }

    private double parseDoubleOrZero(TextField f) {
        if (f == null) return 0.0;
        try {
            String t = f.getText();
            if (t == null || t.isBlank()) return 0.0;
            return Double.parseDouble(t.trim());
        } catch (NumberFormatException ex) {
            return 0.0;
        }
    }

    private void showAlert(String title, String message, Alert.AlertType t) {
        Alert a = new Alert(t);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(message);
        // attempt to set owner so alert is modal to dialog
        if (owner != null) a.initOwner(owner);
        a.showAndWait();
    }
}
