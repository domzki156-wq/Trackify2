package App.controllers;

import App.Session;
import App.dao.DaoFactory;
import App.dao.TransactionDao;
import App.dao.UserDao;
import App.models.Transaction;
import App.models.User;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.nio.file.Path;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * DashboardController - shows transactions and wallet and computes KPIs.
 */
public class DashboardController {

    @FXML private Label usdWalletLabel;
    @FXML private Label phpEquivalentLabel;

    @FXML private Label revenueKpiLabel;
    @FXML private Label costKpiLabel;
    @FXML private Label totalProfitKpiLabel;
    @FXML private Label weeklyProfitKpiLabel;
    @FXML private Label monthlyProfitKpiLabel;

    @FXML private TableView<Transaction> transactionTable;

    @FXML private TableColumn<Transaction, LocalDate> dateColumn;
    @FXML private TableColumn<Transaction, String> customerColumn;
    @FXML private TableColumn<Transaction, String> itemColumn;
    @FXML private TableColumn<Transaction, String> paymentColumn;
    @FXML private TableColumn<Transaction, Double> revenueColumn;
    @FXML private TableColumn<Transaction, Double> costColumn;
    @FXML private TableColumn<Transaction, Double> profitColumn;
    @FXML private TableColumn<Transaction, String> notesColumn;

    private final UserDao userDao = DaoFactory.getUserDao();
    private final TransactionDao txDao = DaoFactory.getTransactionDao();

    private double usdBalance = 0.0;

    // static / simple exchange rate (you can replace with an API later)
    private static final double PH_TO_USD_RATE = 55.0; // 1 USD = 55 PHP (example)
    // If you want dynamic rate, replace with an API call and add caching.

    @FXML
    private void initialize() {
        try {
            if (dateColumn != null) dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
            if (customerColumn != null) customerColumn.setCellValueFactory(new PropertyValueFactory<>("customer"));
            if (itemColumn != null) itemColumn.setCellValueFactory(new PropertyValueFactory<>("item"));
            if (paymentColumn != null) paymentColumn.setCellValueFactory(new PropertyValueFactory<>("paymentMethod"));
            if (revenueColumn != null) revenueColumn.setCellValueFactory(new PropertyValueFactory<>("revenue"));
            if (costColumn != null) costColumn.setCellValueFactory(new PropertyValueFactory<>("cost"));
            if (profitColumn != null) profitColumn.setCellValueFactory(new PropertyValueFactory<>("profit"));
            if (notesColumn != null) notesColumn.setCellValueFactory(new PropertyValueFactory<>("notes"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        Platform.runLater(this::loadUserData);
    }

    private void loadUserData() {
        if (!Session.isAuthenticated()) return;
        User sessionUser = Session.getCurrentUser();
        Optional<User> fresh = userDao.findById(sessionUser.getId());
        fresh.ifPresent(user -> {
            Session.setCurrentUser(user);
            usdBalance = user.getBalance();
            updateWalletLabel();
        });
        loadTransactions();
    }

    private void loadTransactions() {
        transactionTable.getItems().clear();
        if (!Session.isAuthenticated()) return;
        String userId = Session.getCurrentUser().getId();
        List<Transaction> txs = txDao.findAllForUser(userId);
        transactionTable.getItems().addAll(txs);
        // compute KPIs from transactions
        computeAndSetKpis(txs);
    }

    private void computeAndSetKpis(List<Transaction> txs) {
        double totalRevenue = txs.stream().mapToDouble(t -> t.getRevenue()).sum();
        double totalCost = txs.stream().mapToDouble(t -> t.getCost()).sum();
        double totalProfit = txs.stream().mapToDouble(t -> t.getProfit()).sum();

        // weekly = last 7 days
        LocalDate now = LocalDate.now();
        double weeklyProfit = txs.stream()
                .filter(t -> t.getDate() != null && ChronoUnit.DAYS.between(t.getDate(), now) <= 7)
                .mapToDouble(Transaction::getProfit).sum();

        // monthly = last 30 days
        double monthlyProfit = txs.stream()
                .filter(t -> t.getDate() != null && ChronoUnit.DAYS.between(t.getDate(), now) <= 30)
                .mapToDouble(Transaction::getProfit).sum();

        // update KPI labels on FX thread
        Platform.runLater(() -> {
            if (revenueKpiLabel != null) revenueKpiLabel.setText(String.format("%.2f", totalRevenue));
            if (costKpiLabel != null) costKpiLabel.setText(String.format("%.2f", totalCost));
            if (totalProfitKpiLabel != null) totalProfitKpiLabel.setText(String.format("%.2f", totalProfit));
            if (weeklyProfitKpiLabel != null) weeklyProfitKpiLabel.setText(String.format("%.2f", weeklyProfit));
            if (monthlyProfitKpiLabel != null) monthlyProfitKpiLabel.setText(String.format("%.2f", monthlyProfit));
            // update wallet label (should already be current but refresh)
            updateWalletLabel();
        });
    }

    private void updateWalletLabel() {
        usdWalletLabel.setText(String.format("$%.2f", usdBalance));
        // PHP equivalent (rounded)
        double php = usdBalance * PH_TO_USD_RATE;
        if (phpEquivalentLabel != null) phpEquivalentLabel.setText(String.format("₱%.2f", php));
    }

    // ----------------- UI handlers (record, deposit, withdraw, delete, export, buy) ---------------

    @FXML
    private void handleRecordTransaction() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/record-transaction.fxml"));
            Parent root = loader.load();
            RecordTransactionController controller = loader.getController();

            Stage dialog = new Stage();
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.initOwner(usdWalletLabel.getScene().getWindow());
            dialog.setTitle("Record Transaction");

            // register owner and callback
            controller.setOwner(dialog);
            controller.setOnSaved(() -> Platform.runLater(this::loadUserData));

            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/styles/app.css").toExternalForm());
            dialog.setScene(scene);
            dialog.setResizable(false);
            dialog.showAndWait();
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to open record transaction dialog:\n" + ex.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleDeposit() {
        if (!Session.isAuthenticated()) { showAlert("Not logged in", "Please login to deposit.", Alert.AlertType.WARNING); return; }
        TextInputDialog d = new TextInputDialog("0.00");
        d.setTitle("Deposit");
        d.setHeaderText("Deposit to USD Wallet");
        d.setContentText("Amount:");
        d.showAndWait().ifPresent(s -> {
            try {
                double amount = Double.parseDouble(s);
                if (amount <= 0) { showAlert("Invalid amount","Enter a positive number", Alert.AlertType.ERROR); return; }
                usdBalance += amount;
                User u = Session.getCurrentUser();
                u.setBalance(usdBalance);
                userDao.save(u); // persist
                updateWalletLabel();
                showAlert("Deposit successful", String.format("Deposited $%.2f", amount), Alert.AlertType.INFORMATION);
            } catch (NumberFormatException ex) { showAlert("Invalid input","Please enter a valid number.", Alert.AlertType.ERROR); }
        });
    }

    @FXML
    private void handleWithdraw() {
        if (!Session.isAuthenticated()) { showAlert("Not logged in", "Please login to withdraw.", Alert.AlertType.WARNING); return; }
        TextInputDialog d = new TextInputDialog("0.00");
        d.setTitle("Withdraw");
        d.setHeaderText("Withdraw from USD Wallet");
        d.setContentText("Amount:");
        d.showAndWait().ifPresent(s -> {
            try {
                double amount = Double.parseDouble(s);
                if (amount <= 0) { showAlert("Invalid amount","Enter a positive number", Alert.AlertType.ERROR); return; }
                if (amount > usdBalance) { showAlert("Insufficient funds","You don't have enough balance.", Alert.AlertType.ERROR); return; }
                usdBalance -= amount;
                User u = Session.getCurrentUser();
                u.setBalance(usdBalance);
                userDao.save(u);
                updateWalletLabel();
                showAlert("Withdraw successful", String.format("Withdrew $%.2f", amount), Alert.AlertType.INFORMATION);
            } catch (NumberFormatException ex) { showAlert("Invalid input","Please enter a valid number.", Alert.AlertType.ERROR); }
        });
    }

    @FXML
    private void handleDeleteSelected() {
        Transaction sel = transactionTable.getSelectionModel().getSelectedItem();
        if (sel == null) { showAlert("No selection", "Please select a transaction to delete.", Alert.AlertType.WARNING); return; }
        boolean ok = confirm("Delete", "Delete selected transaction?");
        if (!ok) return;
        boolean removed = txDao.deleteById(sel.getId());
        if (removed) {
            loadUserData();
            showAlert("Deleted", "Transaction deleted.", Alert.AlertType.INFORMATION);
        } else {
            showAlert("Failed", "Could not delete transaction.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleExportCsv() {
        try {
            Path out = Path.of(System.getProperty("user.home"), "trackify_transactions.csv");
            txDao.exportCsv(out);
            showAlert("Export complete", "CSV exported to: " + out.toString(), Alert.AlertType.INFORMATION);
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Export failed", ex.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleBuyItems() {
        // simple placeholder; open buy-item.fxml if exists
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/buy-item.fxml"));
            Parent root = loader.load();
            Stage dialog = new Stage();
            dialog.initOwner(usdWalletLabel.getScene().getWindow());
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.setTitle("Buy Items");
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/styles/app.css").toExternalForm());
            dialog.setScene(scene);
            dialog.setResizable(false);
            dialog.showAndWait();
            loadUserData();
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to open buy dialog:\n" + ex.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // helpers
    private void showAlert(String title, String message, Alert.AlertType t) {
        Alert a = new Alert(t);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(message);
        a.initOwner(usdWalletLabel.getScene().getWindow());
        a.showAndWait();
    }

    private boolean confirm(String title, String message) {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(message);
        a.initOwner(usdWalletLabel.getScene().getWindow());
        Optional<ButtonType> res = a.showAndWait();
        return res.isPresent() && res.get() == ButtonType.OK;
    }
}
