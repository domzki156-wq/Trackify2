package App.dao;

import App.models.User;

import java.util.Optional;

/**
 * DAO contract for user persistence.
 */
public interface UserDao {
    Optional<User> findById(String id);

    Optional<User> findByUsername(String username);

    /**
     * Save or update a user (upsert). Return saved user (with id).
     */
    User save(User u);

    /**
     * Update only the user's balance value (used by deposit/withdraw).
     */
    void updateBalance(String userId, double newBalance);

    /**
     * Remove user by id.
     */
    void deleteById(String id);
}
