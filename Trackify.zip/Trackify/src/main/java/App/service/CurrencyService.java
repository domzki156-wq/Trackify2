package App.service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;


public class CurrencyService {


    private static final double FALLBACK_RATE = 56.0;


    public static Double convertUsdToPhp(double usdAmount) throws Exception {
        String url = String.format(
                "https://api.exchangerate.host/convert?from=USD&to=PHP&amount=%s",
                Double.toString(usdAmount)
        );

        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(6))
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(8))
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpResponse<String> resp;
        try {
            resp = client.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception ex) {
            throw new RuntimeException("Network error: " + ex.getMessage(), ex);
        }

        if (resp.statusCode() != 200) {
            throw new RuntimeException("HTTP error from exchange API: " + resp.statusCode());
        }

        String json = resp.body();
        int idx = json.indexOf("\"result\":");
        if (idx >= 0) {
            int start = idx + "\"result\":".length();
            int end = start;
            while (end < json.length() && (Character.isDigit(json.charAt(end)) || ".-Ee".indexOf(json.charAt(end)) >= 0)) end++;
            String num = json.substring(start, end).trim();
            try {
                return Double.parseDouble(num);
            } catch (NumberFormatException ignored) {}
        }


        int idx2 = json.indexOf("\"rate\":");
        if (idx2 >= 0) {
            int start = idx2 + "\"rate\":".length();
            int end = start;
            while (end < json.length() && (Character.isDigit(json.charAt(end)) || ".-Ee".indexOf(json.charAt(end)) >= 0)) end++;
            String rateStr = json.substring(start, end).trim();
            try {
                double rate = Double.parseDouble(rateStr);
                return usdAmount * rate;
            } catch (NumberFormatException ignored) {}
        }


        return usdAmount * FALLBACK_RATE;
    }


    public static double convertUsingFallback(double usdAmount) {
        return usdAmount * FALLBACK_RATE;
    }
}
