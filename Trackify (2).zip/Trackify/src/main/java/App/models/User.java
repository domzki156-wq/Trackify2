package App.models;

import java.time.Instant;
import java.util.Objects;

/**
 * Represents an application user.
 * Stores username, BCrypt-hashed password, creation time, and balance (USD wallet).
 */
public class User {
    private String id;
    private String username;
    private String passwordHash; // BCrypt hash
    private Instant createdAt;
    private double balance; // USD wallet balance

    public User() {}

    // Used during registration
    public User(String username, String passwordHash) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.createdAt = Instant.now();
        this.balance = 0.0;
    }

    // Getters / setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }

    // Utility
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User u = (User) o;
        return Objects.equals(id, u.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
