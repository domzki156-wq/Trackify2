package App.controllers;

import App.Session;
import App.dao.DaoFactory;
import App.dao.TransactionDao;
import App.models.Transaction;
import App.models.User;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.time.LocalDate;

/**
 * Controller for the record-transaction dialog.
 * Expected FXML ids:
 * - DatePicker fx:id="datePicker"
 * - TextField fx:id="customerField"
 * - TextField fx:id="itemField"
 * - ComboBox<String> fx:id="paymentCombo"
 * - TextField fx:id="revenueField"
 * - TextField fx:id="costField"
 * - TextArea fx:id="notesArea"
 */
public class RecordTransactionController {
    @FXML private DatePicker datePicker;
    @FXML private TextField customerField;
    @FXML private TextField itemField;
    @FXML private ComboBox<String> paymentCombo;
    @FXML private TextField revenueField;
    @FXML private TextField costField;
    @FXML private TextArea notesArea;
    @FXML private Label messageLabel;

    private final TransactionDao txDao = DaoFactory.getTransactionDao();

    @FXML
    private void initialize() {
        paymentCombo.getItems().clear();
        paymentCombo.getItems().addAll("PAYPAL", "PAYPAL FNF", "CASH", "CARD");
        paymentCombo.setValue("PAYPAL");
        messageLabel.setText("");
        datePicker.setValue(LocalDate.now());
    }

    @FXML
    private void handleSave() {
        if (!Session.isAuthenticated()) {
            messageLabel.setText("Not logged in");
            return;
        }
        try {
            LocalDate date = datePicker.getValue();
            String customer = customerField.getText() == null ? "" : customerField.getText().trim();
            String item = itemField.getText() == null ? "" : itemField.getText().trim();
            String payment = paymentCombo.getValue();
            double revenue = parseDoubleOrZero(revenueField.getText());
            double cost = parseDoubleOrZero(costField.getText());
            String notes = notesArea.getText();

            if (customer.isBlank() && item.isBlank()) {
                messageLabel.setText("Enter at least customer or item");
                return;
            }

            Transaction t = new Transaction();
            t.setDate(date);
            t.setCustomer(customer);
            t.setItem(item);
            t.setPaymentMethod(payment);
            t.setRevenue(revenue);
            t.setCost(cost);
            t.setNotes(notes);

            // assign current user id before saving
            User user = Session.getCurrentUser();
            t.setUserId(user.getId());

            txDao.save(t);

            // close dialog
            Stage stage = (Stage) customerField.getScene().getWindow();
            stage.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            messageLabel.setText("Failed to save: " + ex.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        Stage stage = (Stage) customerField.getScene().getWindow();
        stage.close();
    }

    private double parseDoubleOrZero(String s) {
        try { return Double.parseDouble(s.trim()); }
        catch (Exception ex) { return 0.0; }
    }
}
