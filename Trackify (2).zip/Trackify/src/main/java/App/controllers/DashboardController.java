package App.controllers;

import App.Session;
import App.dao.DaoFactory;
import App.dao.TransactionDao;
import App.dao.UserDao;
import App.models.Transaction;
import App.models.User;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * DashboardController - shows transactions and wallet.
 * Opens dialogs modally and refreshes data after dialogs close.
 */
public class DashboardController {

    @FXML private Label usdWalletLabel;
    @FXML private TableView<Transaction> transactionTable;

    // DAOs
    private final UserDao userDao = DaoFactory.getUserDao();
    private final TransactionDao txDao = DaoFactory.getTransactionDao();

    private double usdBalance = 0.0;

    @FXML
    private void initialize() {
        // If table columns are defined in FXML they will be used; otherwise create basic ones here:
        try {
            if (transactionTable.getColumns().isEmpty()) {
                TableColumn<Transaction, LocalDate> dateCol = new TableColumn<>("Date");
                dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

                TableColumn<Transaction, String> customerCol = new TableColumn<>("Customer");
                customerCol.setCellValueFactory(new PropertyValueFactory<>("customer"));

                TableColumn<Transaction, String> itemCol = new TableColumn<>("Item");
                itemCol.setCellValueFactory(new PropertyValueFactory<>("item"));

                TableColumn<Transaction, String> payCol = new TableColumn<>("Payment");
                payCol.setCellValueFactory(new PropertyValueFactory<>("paymentMethod"));

                TableColumn<Transaction, Double> revCol = new TableColumn<>("Revenue");
                revCol.setCellValueFactory(new PropertyValueFactory<>("revenue"));

                TableColumn<Transaction, Double> costCol = new TableColumn<>("Cost");
                costCol.setCellValueFactory(new PropertyValueFactory<>("cost"));

                TableColumn<Transaction, Double> profitCol = new TableColumn<>("Profit");
                profitCol.setCellValueFactory(new PropertyValueFactory<>("profit"));

                transactionTable.getColumns().addAll(dateCol, customerCol, itemCol, payCol, revCol, costCol, profitCol);
            }
        } catch (Exception ignored) {}

        // Load user data on the JavaFX thread after UI is ready
        Platform.runLater(this::loadUserData);
    }

    private void loadUserData() {
        if (!Session.isAuthenticated()) return;
        User sessionUser = Session.getCurrentUser();
        // refresh from DB in case something changed
        Optional<User> fresh = userDao.findById(sessionUser.getId());
        fresh.ifPresent(user -> {
            Session.setCurrentUser(user);
            usdBalance = user.getBalance();
            updateWalletLabel();
        });
        loadTransactions();
    }

    private void loadTransactions() {
        transactionTable.getItems().clear();
        if (!Session.isAuthenticated()) return;
        String userId = Session.getCurrentUser().getId();
        List<Transaction> txs = txDao.findAllForUser(userId);
        transactionTable.getItems().addAll(txs);
    }

    private void updateWalletLabel() {
        usdWalletLabel.setText(String.format("$%.2f", usdBalance));
    }

    // ---------------------
    // Handlers (UI actions)
    // ---------------------

    @FXML
    private void handleRecordTransaction() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/record-transaction.fxml"));
            Parent root = loader.load();

            // Get controller in case you want to pre-fill fields later
            // RecordTransactionController controller = loader.getController();

            Stage dialog = new Stage();
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.initOwner(usdWalletLabel.getScene().getWindow());
            dialog.setTitle("Record Transaction");
            Scene scene = new Scene(root);
            // reuse app stylesheet if needed:
            scene.getStylesheets().add(getClass().getResource("/styles/app.css").toExternalForm());
            dialog.setScene(scene);
            dialog.setResizable(false);

            // Show modal; controller itself should save the transaction to DB and close.
            dialog.showAndWait();

            // After the dialog closes, refresh transactions for the user
            loadTransactions();
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to open record transaction dialog:\n" + ex.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleDeleteSelected() {
        Transaction sel = transactionTable.getSelectionModel().getSelectedItem();
        if (sel == null) {
            showAlert("No selection", "Please select a transaction to delete.", Alert.AlertType.WARNING);
            return;
        }
        boolean ok = confirm("Delete", "Delete selected transaction?");
        if (!ok) return;

        boolean removed = txDao.deleteById(sel.getId());
        if (removed) {
            transactionTable.getItems().remove(sel);
            showAlert("Deleted", "Transaction deleted.", Alert.AlertType.INFORMATION);
        } else {
            showAlert("Failed", "Could not delete transaction.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleExportCsv() {
        try {
            Path out = Path.of(System.getProperty("user.home"), "trackify_transactions.csv");
            txDao.exportCsv(out);
            showAlert("Export complete", "CSV exported to: " + out.toString(), Alert.AlertType.INFORMATION);
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Export failed", ex.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleDeposit() {
        if (!Session.isAuthenticated()) { showAlert("Not logged in", "Please login to deposit.", Alert.AlertType.WARNING); return; }
        TextInputDialog d = new TextInputDialog("0.00");
        d.setTitle("Deposit");
        d.setHeaderText("Deposit to USD Wallet");
        d.setContentText("Amount:");
        d.showAndWait().ifPresent(s -> {
            try {
                double amount = Double.parseDouble(s);
                if (amount <= 0) { showAlert("Invalid amount","Enter a positive number", Alert.AlertType.ERROR); return; }
                usdBalance += amount;
                User u = Session.getCurrentUser();
                u.setBalance(usdBalance);
                userDao.save(u); // persist full user doc
                updateWalletLabel();
                showAlert("Deposit successful", String.format("Deposited $%.2f", amount), Alert.AlertType.INFORMATION);
            } catch (NumberFormatException ex) { showAlert("Invalid input","Please enter a valid number.", Alert.AlertType.ERROR); }
        });
    }

    @FXML
    private void handleWithdraw() {
        if (!Session.isAuthenticated()) { showAlert("Not logged in", "Please login to withdraw.", Alert.AlertType.WARNING); return; }
        TextInputDialog d = new TextInputDialog("0.00");
        d.setTitle("Withdraw");
        d.setHeaderText("Withdraw from USD Wallet");
        d.setContentText("Amount:");
        d.showAndWait().ifPresent(s -> {
            try {
                double amount = Double.parseDouble(s);
                if (amount <= 0) { showAlert("Invalid amount","Enter a positive number", Alert.AlertType.ERROR); return; }
                if (amount > usdBalance) { showAlert("Insufficient funds","You don't have enough balance.", Alert.AlertType.ERROR); return; }
                usdBalance -= amount;
                User u = Session.getCurrentUser();
                u.setBalance(usdBalance);
                userDao.save(u);
                updateWalletLabel();
                showAlert("Withdraw successful", String.format("Withdrew $%.2f", amount), Alert.AlertType.INFORMATION);
            } catch (NumberFormatException ex) { showAlert("Invalid input","Please enter a valid number.", Alert.AlertType.ERROR); }
        });
    }

    @FXML
    private void handleBuyItems() {
        // implementation for your "Buy Items" button - open a dialog or webview
        showAlert("Not implemented", "Buy Items action not implemented yet.", Alert.AlertType.INFORMATION);
    }

    /**
     * Opens the currency converter dialog (currency-converter.fxml).
     * This method was missing and caused FXML load error if referenced from dashboard.fxml.
     */
    @FXML
    private void handleCurrencyConverter() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/currency-converter.fxml"));
            Parent root = loader.load();

            Stage dialog = new Stage();
            dialog.initOwner(usdWalletLabel.getScene().getWindow());
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.setTitle("Currency Converter");
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/styles/app.css").toExternalForm());
            dialog.setScene(scene);
            dialog.setResizable(false);
            dialog.showAndWait();
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to open currency converter:\n" + ex.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // ---------------------
    // Helpers
    // ---------------------

    private void showAlert(String title, String message, Alert.AlertType t) {
        Alert a = new Alert(t);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(message);
        a.initOwner(usdWalletLabel.getScene().getWindow());
        a.showAndWait();
    }

    private boolean confirm(String title, String message) {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(message);
        a.initOwner(usdWalletLabel.getScene().getWindow());
        Optional<ButtonType> res = a.showAndWait();
        return res.isPresent() && res.get() == ButtonType.OK;
    }
}
